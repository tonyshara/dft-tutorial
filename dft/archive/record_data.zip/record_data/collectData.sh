brew install portaudio
pip3 install pyaudio
python3 recordDataPoints.py
zip -r wavs.zip wavs

